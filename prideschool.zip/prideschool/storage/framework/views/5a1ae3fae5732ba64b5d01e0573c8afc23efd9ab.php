<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.headerDescription.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.header-descriptions.update", [$headerDescription->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="title"><?php echo e(trans('cruds.headerDescription.fields.title')); ?></label>
                <input class="form-control <?php echo e($errors->has('title') ? 'is-invalid' : ''); ?>" type="text" name="title" id="title" value="<?php echo e(old('title', $headerDescription->title)); ?>" required>
                <?php if($errors->has('title')): ?>
                    <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.headerDescription.fields.title_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="description"><?php echo e(trans('cruds.headerDescription.fields.description')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" name="description" id="description"><?php echo e(old('description', $headerDescription->description)); ?></textarea>
                <?php if($errors->has('description')): ?>
                    <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.headerDescription.fields.description_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="icon"><?php echo e(trans('cruds.headerDescription.fields.icon')); ?></label>
                <input class="form-control <?php echo e($errors->has('icon') ? 'is-invalid' : ''); ?>" type="text" name="icon" id="icon" value="<?php echo e(old('icon', $headerDescription->icon)); ?>">
                <?php if($errors->has('icon')): ?>
                    <span class="text-danger"><?php echo e($errors->first('icon')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.headerDescription.fields.icon_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="cover"><?php echo e(trans('cruds.headerDescription.fields.cover')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('cover') ? 'is-invalid' : ''); ?>" id="cover-dropzone">
                </div>
                <?php if($errors->has('cover')): ?>
                    <span class="text-danger"><?php echo e($errors->first('cover')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.headerDescription.fields.cover_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    Dropzone.options.coverDropzone = {
    url: '<?php echo e(route('admin.header-descriptions.storeMedia')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').find('input[name="cover"]').remove()
      $('form').append('<input type="hidden" name="cover" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="cover"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($headerDescription) && $headerDescription->cover): ?>
      var file = <?php echo json_encode($headerDescription->cover); ?>

          this.options.addedfile.call(this, file)
      this.options.thumbnail.call(this, file, file.preview ?? file.preview_url)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="cover" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
    error: function (file, response) {
        if ($.type(response) === 'string') {
            var message = response //dropzone sends it's own error messages in string
        } else {
            var message = response.errors.file
        }
        file.previewElement.classList.add('dz-error')
        _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
        _results = []
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            node = _ref[_i]
            _results.push(node.textContent = message)
        }

        return _results
    }
}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp3\htdocs\prideschool\resources\views/admin/headerDescriptions/edit.blade.php ENDPATH**/ ?>