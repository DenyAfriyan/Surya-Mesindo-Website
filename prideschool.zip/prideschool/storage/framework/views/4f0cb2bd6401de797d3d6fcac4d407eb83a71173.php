<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Blog</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/scss/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/scss/skin.css')); ?>">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('assets/script/index.js')); ?>"></script>
</head>

<body id="wrapper">

    <!-- HEADER -->
    <?php echo $__env->make('partials/usermenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section id="top_banner">
        <div class="banner" style="background-image: linear-gradient(to bottom, rgba(245, 246, 252, 0.52), rgba(0, 0, 0, 0.83)), url('<?php echo e($blog->cover->getUrl()); ?>')">
            <div class="inner text-center">
                <h2><?php echo e($blog->title); ?></h2>
                <p class="subheading" style="color:white"><?php echo e($blog->author->name . " | " . date("d-m-Y", strtotime($blog->created_at))); ?></p>
            </div>
        </div>
        <div class="page_info">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-6">
                        <h4>Blog</h4>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-6" style="text-align:right;">Home<span class="sep"> 	/ </span><span class="current"> <?php echo e($blog->title); ?></span></div>
                </div>
            </div>
        </div>

        </div>
    </section>

    <section id="portfolio">
        <div class="container">
            <div class="row" id="content">
            </div>
        </div>



    </section>

    <?php echo $__env->make('partials/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</html>

<script>
    var content = '<?php echo e($blog->description); ?>';
    var contenthtml = content.replace(/&lt;/g, '<').replace(/&gt;/g, '>');
    $("#content").html(contenthtml).text(); 
</script><?php /**PATH C:\xampp3\htdocs\prideschool\resources\views/user/detailblog.blade.php ENDPATH**/ ?>