<aside class="main-sidebar sidebar-dark-primary elevation-4" style="min-height: 917px;">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
        <span class="brand-text font-weight-light"><?php echo e(trans('panel.site_title')); ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user (optional) -->

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs("admin.home") ? "active" : ""); ?>" href="<?php echo e(route("admin.home")); ?>">
                        <i class="fas fa-fw fa-tachometer-alt nav-icon">
                        </i>
                        <p>
                            <?php echo e(trans('global.dashboard')); ?>

                        </p>
                    </a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/permissions*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/roles*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/users*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/audit-logs*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle <?php echo e(request()->is("admin/permissions*") ? "active" : ""); ?> <?php echo e(request()->is("admin/roles*") ? "active" : ""); ?> <?php echo e(request()->is("admin/users*") ? "active" : ""); ?> <?php echo e(request()->is("admin/audit-logs*") ? "active" : ""); ?>" href="#">
                            <i class="fa-fw nav-icon fas fa-users">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.userManagement.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.permissions.index")); ?>" class="nav-link <?php echo e(request()->is("admin/permissions") || request()->is("admin/permissions/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-unlock-alt">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.permission.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.roles.index")); ?>" class="nav-link <?php echo e(request()->is("admin/roles") || request()->is("admin/roles/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-briefcase">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.role.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.users.index")); ?>" class="nav-link <?php echo e(request()->is("admin/users") || request()->is("admin/users/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-user">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.user.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('audit_log_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.audit-logs.index")); ?>" class="nav-link <?php echo e(request()->is("admin/audit-logs") || request()->is("admin/audit-logs/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-file-alt">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.auditLog.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('master_data_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/company-profiles*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/header-descriptions*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/category-blogs*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/category-products*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/category-contents*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle <?php echo e(request()->is("admin/company-profiles*") ? "active" : ""); ?> <?php echo e(request()->is("admin/header-descriptions*") ? "active" : ""); ?> <?php echo e(request()->is("admin/category-blogs*") ? "active" : ""); ?> <?php echo e(request()->is("admin/category-products*") ? "active" : ""); ?> <?php echo e(request()->is("admin/category-contents*") ? "active" : ""); ?>" href="#">
                            <i class="fa-fw nav-icon fas fa-database">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.masterData.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('company_profile_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.company-profiles.index")); ?>" class="nav-link <?php echo e(request()->is("admin/company-profiles") || request()->is("admin/company-profiles/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-building">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.companyProfile.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('header_description_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.header-descriptions.index")); ?>" class="nav-link <?php echo e(request()->is("admin/header-descriptions") || request()->is("admin/header-descriptions/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-heading">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.headerDescription.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category_blog_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.category-blogs.index")); ?>" class="nav-link <?php echo e(request()->is("admin/category-blogs") || request()->is("admin/category-blogs/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-archive">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.categoryBlog.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category_product_access')): ?>
                                <!-- <li class="nav-item">
                                    <a href="<?php echo e(route("admin.category-products.index")); ?>" class="nav-link <?php echo e(request()->is("admin/category-products") || request()->is("admin/category-products/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fab fa-bandcamp">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.categoryProduct.title')); ?>

                                        </p>
                                    </a>
                                </li> -->
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category_content_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.category-contents.index")); ?>" class="nav-link <?php echo e(request()->is("admin/category-contents") || request()->is("admin/category-contents/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-th">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.categoryContent.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('content_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/services*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/client-partners*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/portfolios*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/teams*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/blogs*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/products*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/other-contents*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/testimonials*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle <?php echo e(request()->is("admin/services*") ? "active" : ""); ?> <?php echo e(request()->is("admin/client-partners*") ? "active" : ""); ?> <?php echo e(request()->is("admin/portfolios*") ? "active" : ""); ?> <?php echo e(request()->is("admin/teams*") ? "active" : ""); ?> <?php echo e(request()->is("admin/blogs*") ? "active" : ""); ?> <?php echo e(request()->is("admin/products*") ? "active" : ""); ?> <?php echo e(request()->is("admin/other-contents*") ? "active" : ""); ?> <?php echo e(request()->is("admin/testimonials*") ? "active" : ""); ?>" href="#">
                            <i class="fa-fw nav-icon fab fa-first-order">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.content.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.services.index")); ?>" class="nav-link <?php echo e(request()->is("admin/services") || request()->is("admin/services/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-concierge-bell">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.service.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_partner_access')): ?>
                                <!-- <li class="nav-item">
                                    <a href="<?php echo e(route("admin.client-partners.index")); ?>" class="nav-link <?php echo e(request()->is("admin/client-partners") || request()->is("admin/client-partners/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-hands-helping">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.clientPartner.title')); ?>

                                        </p>
                                    </a>
                                </li> -->
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('portfolio_access')): ?>
                                <!-- <li class="nav-item">
                                    <a href="<?php echo e(route("admin.portfolios.index")); ?>" class="nav-link <?php echo e(request()->is("admin/portfolios") || request()->is("admin/portfolios/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-images">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.portfolio.title')); ?>

                                        </p>
                                    </a>
                                </li> -->
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('team_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.teams.index")); ?>" class="nav-link <?php echo e(request()->is("admin/teams") || request()->is("admin/teams/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fab fa-teamspeak">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.team.title')); ?> / Teacher
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('blog_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.blogs.index")); ?>" class="nav-link <?php echo e(request()->is("admin/blogs") || request()->is("admin/blogs/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fab fa-blogger-b">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.blog.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_access')): ?>
                                <!-- <li class="nav-item">
                                    <a href="<?php echo e(route("admin.products.index")); ?>" class="nav-link <?php echo e(request()->is("admin/products") || request()->is("admin/products/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fab fa-product-hunt">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.product.title')); ?>

                                        </p>
                                    </a>
                                </li> -->
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('other_content_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.other-contents.index")); ?>" class="nav-link <?php echo e(request()->is("admin/other-contents") || request()->is("admin/other-contents/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-atlas">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.otherContent.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('testimonial_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.testimonials.index")); ?>" class="nav-link <?php echo e(request()->is("admin/testimonials") || request()->is("admin/testimonials/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-vials">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.testimonial.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inbox_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.inboxes.index")); ?>" class="nav-link <?php echo e(request()->is("admin/inboxes") || request()->is("admin/inboxes/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-inbox">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.inbox.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_alert_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.user-alerts.index")); ?>" class="nav-link <?php echo e(request()->is("admin/user-alerts") || request()->is("admin/user-alerts/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-bell">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.userAlert.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile_password_edit')): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->is('profile/password') || request()->is('profile/password/*') ? 'active' : ''); ?>" href="<?php echo e(route('profile.password.edit')); ?>">
                                <i class="fa-fw fas fa-key nav-icon">
                                </i>
                                <p>
                                    <?php echo e(trans('global.change_password')); ?>

                                </p>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
                <li class="nav-item">
                    <a href="#" class="nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                        <p>
                            <i class="fas fa-fw fa-sign-out-alt nav-icon">

                            </i>
                            <p><?php echo e(trans('global.logout')); ?></p>
                        </p>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside><?php /**PATH C:\xampp3\htdocs\prideschool\resources\views/partials/menu.blade.php ENDPATH**/ ?>