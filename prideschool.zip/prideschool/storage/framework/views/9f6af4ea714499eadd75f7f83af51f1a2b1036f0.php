<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Blog</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/scss/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/scss/skin.css')); ?>">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('assets/script/index.js')); ?>"></script>
</head>

<body id="wrapper">

    <!-- HEADER -->
    <?php echo $__env->make('partials/usermenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section id="top_banner">
        <div class="banner">
            <div class="inner text-center">
                <h2>Blog</h2>
            </div>
        </div>
        <div class="page_info">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-6">
                        <h4>Blog</h4>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-6" style="text-align:right;">Home<span class="sep"> 	/ </span><span class="current"> Blog</span></div>
                </div>
            </div>
        </div>

        </div>
    </section>

    <section id="portfolio">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 portfolio-item">
                    <a href="<?php echo e(route('detailblog', [$item->title])); ?>">
                    <div class="portfolio-one">
                        <div class="portfolio-head">
                            <div class="portfolio-img"><img alt="" src="<?php echo e($item->cover->getUrl()); ?>"></div>
                        </div>
                        <!-- End portfolio-head -->
                        <div class="portfolio-content">
                            <h5 class="title"><?php echo e($item->title); ?></h5>
                            <p><?php echo e($item->short_description); ?></p>
                        </div>
                        <!-- End portfolio-content -->
                    </div>
                    </a>
                    <!-- End portfolio-item -->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination pagination-lg justify-content-end">
                        <?php echo $blogs->links(); ?>

                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </section>

    <?php echo $__env->make('partials/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</html>

<script>
    (function(){
var i,e,d=document,s="script";i=d.createElement("script");i.async=1;i.charset="UTF-8";
i.src="https://cdn.curator.io/published/edff91eb-e440-4ce9-98d7-3725806fa580.js";
e=d.getElementsByTagName(s)[0];e.parentNode.insertBefore(i, e);
})();
</script><?php /**PATH C:\xampp3\htdocs\prideschool\resources\views/user/blog.blade.php ENDPATH**/ ?>