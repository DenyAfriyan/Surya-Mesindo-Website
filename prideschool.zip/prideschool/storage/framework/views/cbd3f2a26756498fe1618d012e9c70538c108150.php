<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.inbox.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.inboxes.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.inbox.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($inbox->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.inbox.fields.name')); ?>

                        </th>
                        <td>
                            <?php echo e($inbox->name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.inbox.fields.phone')); ?>

                        </th>
                        <td>
                            <?php echo e($inbox->phone); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.inbox.fields.email')); ?>

                        </th>
                        <td>
                            <?php echo e($inbox->email); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.inbox.fields.subject')); ?>

                        </th>
                        <td>
                            <?php echo e($inbox->subject); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.inbox.fields.description')); ?>

                        </th>
                        <td>
                            <?php echo e($inbox->description); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.inbox.fields.is_read')); ?>

                        </th>
                        <td>
                            <?php echo e($inbox->is_read); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.inboxes.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp3\htdocs\prideschool\resources\views/admin/inboxes/show.blade.php ENDPATH**/ ?>