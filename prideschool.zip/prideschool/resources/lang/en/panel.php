<?php

return [
    'site_title' => 'Company Profile',
];
