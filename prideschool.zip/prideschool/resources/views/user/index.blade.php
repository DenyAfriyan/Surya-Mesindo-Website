<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Home</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="{{ asset('assets/scss/main.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/scss/skin.css') }}">
    <link rel="icon" type="image/x-icon" href="{{$company->logo->getUrl()}}">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script src="{{ asset('assets/script/index.js') }}"></script>
</head>

<body id="wrapper">

    

    <!-- HEADER -->
    @include('partials/usermenu')

    <!--/.nav-ends -->
    <div id="myCarousel" class="carousel slide">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <?php $index = 0 ?>
            @foreach($header as $item)
            @if($index == 0)
            <li data-target="#myCarousel" data-slide-to="{{$index}}" class="active"></li>
            @else
            <li data-target="#myCarousel" data-slide-to="{{$index}}"></li>
            @endif
            <?php $index++ ?>
            @endforeach
        </ol>

        <?php
            $phone = "https://wa.me/".$company->phone."/?text=Hallo Pride Home Schooling";
        ?>
        <!-- Wrapper for slides -->
        <div class="carousel-inner">
            <?php $index = 0 ?>
            @foreach($header as $item)
            @if($index == 0)
            <div class="item active">
                <div class="fill" style="background-image:url('{{$item->cover->getUrl()}}');"></div>
                <div class="carousel-caption slide-up">
                    <h1 class="banner_heading">{{$item->title}}</h1>
                    <p class="banner_txt">{{$item->description}}</p>
                    <div class="slider_btn">
                        <a href="{{$phone}}" class="btn btn-primary slide">Send Whatsapp <i class="fa fa-caret-right"></i></a>
                    </div>
                </div>
            </div>
            @else
            <div class="item">
                <div class="fill" style="background-image:url('{{$item->cover->getUrl()}}');"></div>
                <div class="carousel-caption slide-up">
                    <h1 class="banner_heading">{{$item->title}}</h1>
                    <p class="banner_txt">{{$item->description}}</p>
                    <div class="slider_btn">
                    <a href="{{$phone}}" class="btn btn-primary slide">Send Whatsapp <i class="fa fa-caret-right"></i></a>
                    </div>
                </div>
            </div>
            @endif
            <?php $index++ ?>
            @endforeach
        </div>

        <!-- Left and right controls -->

        <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev"> <i class="fa fa-angle-left" aria-hidden="true"></i>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next"> <i class="fa fa-angle-right" aria-hidden="true"></i>
            <span class="sr-only">Next</span>
        </a>

    </div>

    <section id="features" style="margin-top: 50px; margin-bottom: 50px">
        <div class="container">
            <div class="row">
                <div class="section-heading" style="margin-bottom: 50px">
                    <h1 class="text-center">Layanan <span>Pembelajaran</span></h1>
                </div>
                @foreach($services as $item)
                <div class="col-md-3 col-xs-12 block">
                    <div class="col-md-2 col-xs-2"><i class="fa fa-certificate feature_icon"></i></div>
                    <div class="col-md-10 col-xs-10">
                        <h4>{{$item->title}}</h4>
                        <p>{{$item->description}}</p>
                        <!-- <a href="#" class="readmore">Read More <i class="fa fa-caret-right"></i></a> -->
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </section>


    <section id="about">
        <div class="image-holder col-lg-6 col-md-6 col-sm-6 col-xs-12 pull-left">
            <div class="background-imgholder">
                <img src="{{asset('assets/img/9.jpg')}}" alt="about" class="img-responsive" style="display:none;" />
            </div>
        </div>

        <div class="container-fluid">

            <div class="col-md-7 col-md-offset-5 col-sm-8 col-sm-offset-2 col-xs-12 text-inner ">
                <div class="text-block">
                    <div class="section-heading">
                        <h1>ABOUT <span>US</span></h1>
                        <p class="subheading">{{$company->about}}</p>
                    </div>

                    <button type="button" class="btn btn-primary slide">Learn More  <i class="fa fa-caret-right"></i> </button>


                </div>
            </div>
        </div>
    </section>


    <section id="process">
        <div class="container">
            <div class="section-heading text-center">
                <div class="col-md-12 col-xs-12">
                    <h1>Gallery <span>Pride</span></h1>
                    <p class="subheading">Kegiatan dan Program-Program Pride Homeschooling Tangerang Selatan.</p>
                </div>
            </div>

            <div class="row">
                <div id="curator-feed-bisakan-layout"><a href="https://curator.io" target="_blank" class="crt-logo crt-tag">Powered by Curator.io</a></div>
            </div>

        </div>
    </section>

    <section id="testimonial">
        <div class="container">
            <div class="section-heading text-center">
                <div class="col-md-12 col-xs-12">
                    <h1>Testimonial</h1>
                    <p class="subheading">What Student Parents Says</p>
                </div>
            </div>

            <div class="row">
                @foreach($testimonials as $item)
                <div class="col-md-4 col-sm-12 block ">
                    <div class="testimonial_box">
                        <p>{{$item->testimoni}} </p>
                    </div>
                    <div class="arrow-down"></div>
                    <div class="testimonial_user">
                        <div class="user-image"><img src="{{$item->photos->getUrl()}}" alt="user" class="img-responsive" /></div>
                        <div class="user-info">
                            <h5>{{$item->name}}</h5>
                            <p>{{$item->job}}</p>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>

    </section>

    @include('partials/footer')


</html>

<script>
    (function(){
var i,e,d=document,s="script";i=d.createElement("script");i.async=1;i.charset="UTF-8";
i.src="https://cdn.curator.io/published/edff91eb-e440-4ce9-98d7-3725806fa580.js";
e=d.getElementsByTagName(s)[0];e.parentNode.insertBefore(i, e);
})();
</script>